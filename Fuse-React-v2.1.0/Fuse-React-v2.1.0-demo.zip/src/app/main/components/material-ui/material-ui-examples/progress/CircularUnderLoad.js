import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

function CircularUnderLoad() {
  return <CircularProgress disableShrink />;
}

export default CircularUnderLoad;
